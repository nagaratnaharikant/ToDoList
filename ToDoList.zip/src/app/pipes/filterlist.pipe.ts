import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterlist'
})
export class FilterlistPipe implements PipeTransform {

  transform(items: any, sel?: any): any {
    return items.filter(function (obj) {
      return Object.keys(obj).some(function (key) {
        // console.log(obj);
        return obj;
      });
    });
  }
}
