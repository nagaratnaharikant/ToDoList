import { FilterlistPipe } from './filterlist.pipe';

describe('FilterlistPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterlistPipe();
    expect(pipe).toBeTruthy();
  });
});
