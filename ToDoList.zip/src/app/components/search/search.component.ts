import { TodoService } from './../../services/todo.service';
import { Component, OnInit, Pipe } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
})
export class SearchComponent implements OnInit {

  constructor(private listService: TodoService) { }

  ngOnInit() {
  }

}
